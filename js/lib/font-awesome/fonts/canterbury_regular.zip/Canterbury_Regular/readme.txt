﻿Congratulations, you have successfully downloaded @font-face kit! 

This kit is provided to you by Fonts2u.com – the largest online 
repository of free fonts for Windows and Mac.


How to use this @font-face kit?

In order to embed the font into your web site, please, do the following:

1. Upload the four font files (.ttf,.woff,.eot,.svg) and the stylesheet.css to 
    your website using your hosting account control panel or via ftp. All
    these files are available in the fontface .zip root directory.

2. Declare the chosen font by copying the generated CSS code provided in
   @font-face kit and paste it into your main CSS file, or simply import
   it as a separate CSS.

3. Link the embedded font with any element you like using standard CSS 
   syntax (f.e. h1 {font-family:'declared font name';}

4. Enjoy the new font on your web site. 
